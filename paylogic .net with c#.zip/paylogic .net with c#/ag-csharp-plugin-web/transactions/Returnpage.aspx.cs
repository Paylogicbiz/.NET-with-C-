﻿using Encryption.AES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MerchantSuccess : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Params.Count > 0)
        {

            string secretkey = "8c1d1fe7354a4d2e";
            string STATUS = (!String.IsNullOrEmpty(Request.Params["STATUS"])) ? Request.Params["STATUS"] : string.Empty;
            string APP_ID = (!String.IsNullOrEmpty(Request.Params["APP_ID"])) ? Request.Params["APP_ID"] : string.Empty;
            string TXN_ID = (!String.IsNullOrEmpty(Request.Params["TXN_ID"])) ? Request.Params["TXN_ID"] : string.Empty;
            string TXNTYPE = (!String.IsNullOrEmpty(Request.Params["TXNTYPE"])) ? Request.Params["TXNTYPE"] : string.Empty;
            string RETURN_URL = (!String.IsNullOrEmpty(Request.Params["RETURN_URL"])) ? Request.Params["RETURN_URL"] : string.Empty;
            string ORDER_ID = (!String.IsNullOrEmpty(Request.Params["ORDER_ID"])) ? Request.Params["ORDER_ID"] : string.Empty;
            string RESPONSE_DATE_TIME = (!String.IsNullOrEmpty(Request.Params["RESPONSE_DATE_TIME"])) ? Request.Params["RESPONSE_DATE_TIME"] : string.Empty;
           // string RESPONSE_DATE_TIME = datentime.Replace("+", "");
            string RESPONSE_CODE = (!String.IsNullOrEmpty(Request.Params["RESPONSE_CODE"])) ? Request.Params["RESPONSE_CODE"] : string.Empty;
            string ACQ_ID = (!String.IsNullOrEmpty(Request.Params["ACQ_ID"])) ? Request.Params["ACQ_ID"] : string.Empty;
            string CARD_MASK = (!String.IsNullOrEmpty(Request.Params["CARD_MASK"])) ? Request.Params["CARD_MASK"] : string.Empty;
            string DUPLICATE_YN = (!String.IsNullOrEmpty(Request.Params["DUPLICATE_YN"])) ? Request.Params["DUPLICATE_YN"] : string.Empty;
            string MOP_TYPE = (!String.IsNullOrEmpty(Request.Params["MOP_TYPE"])) ? Request.Params["MOP_TYPE"] : string.Empty;
            string PAYMENT_TYPE = (!String.IsNullOrEmpty(Request.Params["PAYMENT_TYPE"])) ? Request.Params["PAYMENT_TYPE"] : string.Empty;
            string RESPONSE_MESSAGE = (!String.IsNullOrEmpty(Request.Params["RESPONSE_MESSAGE"])) ? Request.Params["RESPONSE_MESSAGE"] : string.Empty;
            //string RESPONSE_MESSAGE = responsemsg.Replace("+", "");
            string CUST_PHONE = (!String.IsNullOrEmpty(Request.Params["CUST_PHONE"])) ? Request.Params["CUST_PHONE"] : string.Empty;
            string CUST_NAME = (!String.IsNullOrEmpty(Request.Params["CUST_NAME"])) ? Request.Params["CUST_NAME"] : string.Empty;
            string CUST_EMAIL = (!String.IsNullOrEmpty(Request.Params["CUST_EMAIL"])) ? Request.Params["CUST_EMAIL"] : string.Empty;
            string CURRENCY_CODE = (!String.IsNullOrEmpty(Request.Params["CURRENCY_CODE"])) ? Request.Params["CURRENCY_CODE"] : string.Empty;
            string AMOUNT = (!String.IsNullOrEmpty(Request.Params["AMOUNT"])) ? Request.Params["AMOUNT"] : string.Empty;
            string RRN = (!String.IsNullOrEmpty(Request.Params["RRN"])) ? Request.Params["RRN"] : string.Empty;
            string ORIG_TXN_ID = (!String.IsNullOrEmpty(Request.Params["ORIG_TXN_ID"])) ? Request.Params["ORIG_TXN_ID"] : string.Empty;
            string AUTH_CODE = (!String.IsNullOrEmpty(Request.Params["AUTH_CODE"])) ? Request.Params["AUTH_CODE"] : string.Empty;
            string responsehash = (!String.IsNullOrEmpty(Request.Params["HASH"])) ? Request.Params["HASH"] : string.Empty;

            var response = new SortedDictionary<string, string>();
            response.Add("STATUS", STATUS);
            response.Add("APP_ID", APP_ID);
            response.Add("TXN_ID", TXN_ID);
            response.Add("TXNTYPE", TXNTYPE);
            response.Add("RETURN_URL", RETURN_URL);
            response.Add("ORDER_ID", ORDER_ID);
            response.Add("RESPONSE_DATE_TIME", RESPONSE_DATE_TIME);
            response.Add("RESPONSE_CODE", RESPONSE_CODE);
            response.Add("ACQ_ID", ACQ_ID);
            response.Add("CARD_MASK", CARD_MASK);
            response.Add("DUPLICATE_YN", DUPLICATE_YN);
            response.Add("MOP_TYPE", MOP_TYPE);
            response.Add("PAYMENT_TYPE", PAYMENT_TYPE);
            response.Add("RESPONSE_MESSAGE", RESPONSE_MESSAGE);
            response.Add("CUST_PHONE", CUST_PHONE);
            response.Add("CUST_NAME", CUST_NAME);
            response.Add("CUST_EMAIL", CUST_EMAIL);
            response.Add("CURRENCY_CODE", CURRENCY_CODE);
            response.Add("AMOUNT", AMOUNT);
            response.Add("RRN", RRN);
            response.Add("ORIG_TXN_ID", ORIG_TXN_ID);
            response.Add("AUTH_CODE", AUTH_CODE);


            string data = "";
            string all = "";
            string hash = "";
            MyCryptoClass aes = new MyCryptoClass();

            foreach (var item in response)
            {
                if(item.Value.Length > 0) {
                    data += item.Key + "=" + item.Value + "~";
                    all = data.Remove(data.Length - 1, 1);
                    all += secretkey;
                    hash = aes.ComputeSha256Hash(all);
                }
              
               
            }

            string message = "Hash Mismatched";

            if (responsehash.Equals(hash))
            {
                 message = "Hash Matched";
            }



            lblAgRef.Text = TXN_ID;
            lblAmount.Text = AMOUNT;
            lblOrderNumber.Text = ORDER_ID;
            lblResponseMessage.Text = RESPONSE_MESSAGE;
            lblTransactionDate.Text = RESPONSE_DATE_TIME;
            lblTransactionStatus.Text = STATUS;
             
        }
    }
}