﻿using System;
using Encryption.AES;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Linq;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       

   }

    protected void btns_Click(object sender, EventArgs e)
    {
        string appid = (!String.IsNullOrEmpty(APP_ID.Value)) ? APP_ID.Value : string.Empty;
        string secretkey = (!String.IsNullOrEmpty(key.Value)) ? key.Value : string.Empty;
        string orderno = (!String.IsNullOrEmpty(order_no.Value)) ? order_no.Value : string.Empty;
        string cost = (!String.IsNullOrEmpty(amount.Value)) ? amount.Value : string.Empty;
        string currencyCode = (!String.IsNullOrEmpty(currency.Value)) ? currency.Value : string.Empty;
        string txnType = (!String.IsNullOrEmpty(txn_type.Value)) ? txn_type.Value : string.Empty;
        string returnURL = (!String.IsNullOrEmpty(return_url.Value)) ? return_url.Value : string.Empty;
        string custname = (!String.IsNullOrEmpty(cust_name.Value)) ? cust_name.Value : string.Empty;
        string emailid = (!String.IsNullOrEmpty(email_id.Value)) ? email_id.Value : string.Empty;
        string mobileNo = (!String.IsNullOrEmpty(mobile_no.Value)) ? mobile_no.Value : string.Empty;
        string custAddress = (!String.IsNullOrEmpty(street_address.Value)) ? street_address.Value : string.Empty;
        string paymentType = (!String.IsNullOrEmpty(payment_type.Value)) ? payment_type.Value : string.Empty;
        string mopType = (!String.IsNullOrEmpty(moptype.Value)) ? moptype.Value : string.Empty;
        string zipcode = (!String.IsNullOrEmpty(zip_code.Value)) ? zip_code.Value : string.Empty;


        var value = new SortedDictionary<string, string>();
        value.Add("APP_ID", appid);
        value.Add("ORDER_ID", orderno);
        value.Add("AMOUNT", cost);
        value.Add("CURRENCY_CODE", currencyCode);
        value.Add("TXNTYPE", txnType);
        value.Add("RETURN_URL", returnURL);
        value.Add("CUST_NAME", custname);
        value.Add("CUST_EMAIL", emailid);
        value.Add("CUST_PHONE", mobileNo);
        value.Add("CUST_STREET_ADDRESS1", custAddress);
       // value.Add("PAYMENT_TYPE", paymentType);
        //value.Add("MOP_TYPE", mopType);
        value.Add("CUST_ZIP", zipcode);

        /*
                Console.WriteLine("Sorted by Key");
                Console.WriteLine("=============");
        */


        string data = "";
        string all = "";
        string hash = "";
        MyCryptoClass aes = new MyCryptoClass();

        foreach (var item in value)
        {
            data += item.Key + "=" + item.Value + "~";
            all = data.Remove(data.Length - 1, 1);
            all += secretkey;
            hash = aes.ComputeSha256Hash(all);
        }

  

        NameValueCollection line = new NameValueCollection();
        line.Add("APP_ID", appid);
        line.Add("ORDER_ID", orderno);
        line.Add("AMOUNT", cost);
        line.Add("CURRENCY_CODE", currencyCode);
        line.Add("TXNTYPE", txnType);
        line.Add("RETURN_URL", returnURL);
        line.Add("CUST_NAME", custname);
        line.Add("CUST_EMAIL", emailid);
        line.Add("CUST_PHONE", mobileNo);
        line.Add("CUST_STREET_ADDRESS1", custAddress);
        line.Add("CUST_ZIP", zipcode);
        line.Add("HASH", hash);
        HttpHelper.RedirectAndPOST(this.Page, "https://pg.paylogic.biz/v1/jsp/paymentrequest", line);
    }
}